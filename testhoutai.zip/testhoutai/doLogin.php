<?php
/**
 * Created by PhpStorm.
 * User: JHN
 * Date: 2018/4/4
 * Time: 9:57
 */
//检查账号密码
session_start();
$username = $_POST['username'];
$pwd = $_POST['password'];

if (!$username) {
    echo "<script>alert('请输入用户名');
window.location='login.php';</script>";
}
if (!$pwd) {
    echo "<script>alert('请输入密码');window.location='login.php';</script>";
}
$sql = "select * from `admin` where `username`='{$username}' and pwd='{$pwd}'";
$db = mysqli_connect('106.14.177.245', 'root', '31501370', 'lanou');
$result = mysqli_query($db, $sql);
$row = mysqli_fetch_assoc($result);

if ($row == null) {
    echo "<script>alert('账号或密码错误，请重新登录');
window.location='login.php';</script>";
} else {
    $_SESSION['admin']=$row['username'];
//    $_COOKIE['admin']=$row['username'];
    echo "<script>window.location='index.php';</script>";
}