<?php
/**
 * Created by PhpStorm.
 * User: JHN
 * Date: 2018/4/4
 * Time: 13:46
 */
//退出登录
session_start();
$_SESSION=Array();
if(isset($_COOKIE[session_name()])){
    setcookie(session_name(),"",    time()-1);

}
session_destroy();


header("location:login.php");