// JavaScript Document
DD_belatedPNG.fix('div,ul,ol,li,dt,dd,dl,span,img,a,em,strong,h1,h2,h3,h4,h5,h6,p');
//尽量少偷懒，不要用*，性能是很低的
