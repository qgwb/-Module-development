<?php
session_start();
if($_SESSION['admin']==null){
    echo "<script>alert('请先登录');
window.location='login.php';</script>";
}
?>
<!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <title>后台管理系统</title>
    <link rel="stylesheet" href="style/backstage.css">
</head>
<body>
<div class="head">
    <div class="logo fl"><a href="#"></a></div>
    <h3 class="head_text fr">资源回收平台后台管理系统</h3>
</div>
<div class="operation_user clearfix">
<!--    <div class="link fl"><a href="#">慕课</a><span>&gt;&gt;</span><a href="#">商品管理</a><span>&gt;&gt;</span>商品修改</div>-->
    <div class="link fr">
        <a href="index.php" class="icon icon_i">首页</a><span></span><a href="logout.php" class="icon icon_e">退出</a>
    </div>
</div>
<div class="content clearfix">
    <div class="main">
        <div class="cont">
            <!--右侧内容-->

            <iframe src="main.php" name="manage1" style="width:100%;height:500px"></iframe>
        </div>
    </div>
    <div class="menu">
        <div class="cont">
            <div class="title">管理员</div>
            <ul class="mList">
                <li>
                    <h3><a href="citizenmanager.php" target="manage1" style="font-size: 18px">居民管理</a></h3>
                    <dl>
                        <dd><a href="#">添加居民</a></dd>

                    </dl>
                </li>
                <li>
                    <h3><a href="recyclemanager.php" target="manage1" style="font-size: 18px">回收员管理</a></h3>
                    <dl>
                        <dd><a href="#">添加回收员</a></dd>

                    </dl>
                </li>

                <li>
                    <h3><a href="typemanager.php" target="manage1" style="font-size: 18px">种类管理</a></h3>
                    <dl>
                        <dd><a href="#">添加种类</a></dd>

                    </dl>
                </li>
                <li>
                    <h3><a href="ordermanager.php" target="manage1" style="font-size: 18px">订单管理</a></h3>
                    <dl>
                        <dd><a href="#">订单列表</a></dd>

                    </dl>
                </li>
            </ul>
        </div>
    </div>
</div>

</body>
</html>