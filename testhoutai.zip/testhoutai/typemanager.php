<!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <title>后台管理系统</title>
    <link rel="stylesheet" href="style/backstage.css">
</head>
<body>



<div class="title">订单管理</div>
<div class="details">
    <div class="details_operation clearfix">
        <div class="bui_select">
            <input type="button" value="添&nbsp;&nbsp;加" class="add">
        </div>
<!--        <div class="fr">-->
<!--            <div class="text">-->
<!--                <span>商品名称：</span>-->
<!--                <div class="bui_select">-->
<!--                    <select name="" id="1" class="select">-->
<!--                        <option value="1">测试内容</option>-->
<!--                        <option value="1">测试内容</option>-->
<!--                        <option value="1">测试内容</option>-->
<!--                    </select>-->
<!--                </div>-->
<!--            </div>-->
<!--            <div class="text">-->
<!--                <span>上架时间：</span>-->
<!--                <div class="bui_select">-->
<!--                    <select name="" id="" class="select">-->
<!--                        <option value="1">测试内容</option>-->
<!--                        <option value="1">测试内容</option>-->
<!--                        <option value="1">测试内容</option>-->
<!--                    </select>-->
<!--                </div>-->
<!--            </div>-->
<!--            <div class="text">-->
<!--                <span>搜索</span>-->
<!--                <input type="text" value="" class="search">-->
<!--            </div>-->
<!--        </div>-->
    </div>
    <!--表格-->
    <table class="table" cellspacing="0" cellpadding="0">
        <thead>
        <tr>
            <th width="15%">编号</th>
            <th width="25%">标题</th>
            <th width="35%">来源</th>
            <th>操作</th>
        </tr>
        </thead>
        <tbody>
        <!--        //数据库写在下面-->
        <tr>
            <td><input type="checkbox" id="c9" class="check"><label for="c9" class="label">001</label></td>
            <td>后台设计</td>
            <td>测试内容</td>
            <td align="center"><input type="button" value="修改" class="btn"><input type="button" value="删除" class="btn"></td>
        </tr>
        </tbody>
    </table>
</div>


</body>
</html>