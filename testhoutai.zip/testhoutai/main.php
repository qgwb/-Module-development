<!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <title>后台管理系统</title>
    <link rel="stylesheet" href="style/backstage.css">
</head>
<body>



<div class="title">欢迎！</div>
<div class="details">
    <div class="details_operation clearfix">
    </div>
</div>
</body>
</html>